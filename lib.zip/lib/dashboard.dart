import 'package:flutter/material.dart';
import 'package:gtech/adminpanel.dart';
import 'package:gtech/coursehome.dart';
import 'package:gtech/modules.dart';

class DashboardScreen extends StatefulWidget {
  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  String selectedContent = 'Course Content';
  TextEditingController searchController = TextEditingController();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  void updateContent(String newContent) {
    setState(() {
      selectedContent = newContent;
    });
  }

  void handleMenuSelection(String value) {
    if (value == 'Settings') {
      updateContent('Settings');
    } else if (value == 'Sign Out') {
      Navigator.push(context, MaterialPageRoute(builder: (context) => Adminpanel()));
    }
  }

  @override
  Widget build(BuildContext context) {
    final isLargeScreen = MediaQuery.of(context).size.width >= 700;

    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.grey[200],
      appBar: isLargeScreen
          ? null
          : AppBar(
              title: Text('Dashboard'),
              leading: IconButton(
                icon: Icon(Icons.menu),
                onPressed: () => _scaffoldKey.currentState!.openDrawer(),
              ),
              actions: [
                PopupMenuButton<String>(
                  onSelected: handleMenuSelection,
                  itemBuilder: (BuildContext context) {
                    return {'Settings', 'Sign Out'}.map((String choice) {
                      return PopupMenuItem<String>(
                        value: choice,
                        child: Text(choice),
                      );
                    }).toList();
                  },
                ),
              ],
            ),
      drawer: isLargeScreen
          ? null
          : Drawer(
              child: Sidebar(
                isLargeScreen: isLargeScreen,
                onMenuItemSelected: (menu) {
                  updateContent(menu);
                },
                searchController: searchController,
              ),
            ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          return Row(
            children: [
              if (isLargeScreen)
                Sidebar(
                  isLargeScreen: isLargeScreen,
                  onMenuItemSelected: updateContent,
                  searchController: searchController,
                ),
              Expanded(
                child: ContentArea(
                  isLargeScreen: isLargeScreen,
                  selectedContent: selectedContent,
                  searchController: searchController,
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class Sidebar extends StatelessWidget {
  final Function(String) onMenuItemSelected;
  final TextEditingController searchController;
  final bool isLargeScreen;

  Sidebar({required this.onMenuItemSelected, required this.searchController, required this.isLargeScreen});

  @override
  Widget build(BuildContext context) {
    final sidebarWidth = isLargeScreen ? 300.0 : MediaQuery.of(context).size.width * 0.8;

    return Card(
      elevation: 4,
      child: Container(
        color: Colors.white,
        width: sidebarWidth,
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            UserCard(),
            SizedBox(height: 20),
            SearchField(searchController: searchController),
            SizedBox(height: 20),
            Expanded(
              child: SingleChildScrollView(
                child: MainMenu(
                  isLargeScreen: isLargeScreen,
                  onMenuItemSelected: onMenuItemSelected,
                ),
              ),
            ),
            SidebarButton(
              icon: Icons.settings,
              text: 'Settings',
              isSelected: false,
              onTap: () => onMenuItemSelected('Settings'),
            ),
            SidebarButton(
              icon: Icons.logout,
              text: 'Sign Out',
              isSelected: false,
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Adminpanel()),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// The rest of your classes (UserCard, SearchField, MainMenu, SidebarButton, ContentArea) remain unchanged


class UserCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Profile Icon on the left
            CircleAvatar(
              radius: 20,
              backgroundColor: const Color.fromARGB(255, 0, 0, 0),
              child: Icon(Icons.person, color: Colors.white, size: 20),
            ),
            SizedBox(width: 12),

            // Information on the right
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Name
                Text(
                  'Mishal Mehroof',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.black87,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),

                // Email
                Text(
                  'Mishalgtec@gtec.com',
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.grey[600],
                  ),
                  overflow: TextOverflow.ellipsis,
                ),

                SizedBox(height: 8),

                // Role Badge
                Container(
                  decoration: BoxDecoration(
                    color: Colors.blue[50],
                    borderRadius: BorderRadius.circular(8),
                  ),
                  padding: EdgeInsets.symmetric(vertical: 4, horizontal: 8),
                  child: Text(
                    'Super Admin',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: const Color.fromARGB(255, 66, 72, 80),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class SearchField extends StatelessWidget {
  final TextEditingController searchController;

  SearchField({required this.searchController});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            spreadRadius: 2,
            blurRadius: 5,
            offset: Offset(0, 2), // changes position of shadow
          ),
        ],
      ),
      child: TextField(
        controller: searchController,
        decoration: InputDecoration(
          contentPadding: EdgeInsets.symmetric(vertical: 14, horizontal: 16),
          prefixIcon: Icon(
            Icons.search,
            color: Colors.blueGrey,
          ),
          labelText: 'Search...',
          labelStyle: TextStyle(color: Colors.blueGrey),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.blueGrey),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: const Color.fromARGB(255, 6, 7, 8)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.blueGrey),
          ),
        ),
      ),
    );
  }
}

class MainMenu extends StatefulWidget {
  final Function(String) onMenuItemSelected;
  final bool isLargeScreen;  // Accepting isLargeScreen

  MainMenu({required this.onMenuItemSelected, required this.isLargeScreen});

  @override
  _MainMenuState createState() => _MainMenuState();
}

class _MainMenuState extends State<MainMenu> {
  String selectedMenu = '';

  void updateSelectedMenu(String newMenu) {
    setState(() {
      selectedMenu = newMenu;
    });
    widget.onMenuItemSelected(newMenu);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(0, 0, 0, 5),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.only(
          topRight: Radius.circular(16),
          bottomRight: Radius.circular(16),
        ),
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            spreadRadius: 1,
            blurRadius: 5,
            offset: Offset(2, 3),
          ),
        ],
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.fromLTRB(0, 0, 0, 10),
              child: Text(
                'Main Menu',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            SidebarButton(
              icon: Icons.home,
              text: 'Dashboard',
              isSelected: selectedMenu == 'Dashboard',
              onTap: () => updateSelectedMenu('Dashboard'),
            ),
            _buildExpandableTile(
              icon: Icons.school,
              title: 'Course Management',
              isSelected: selectedMenu == 'Course Management',
              children: [
                'Add New Course',
                'Manage Course',
                'Course Bundle',
              ],
              onMenuItemSelected: updateSelectedMenu,
              isLargeScreen: widget.isLargeScreen,  // Pass isLargeScreen
            ),
            _buildExpandableTile(
              icon: Icons.quiz,
              title: 'Quiz Management',
              isSelected: selectedMenu == 'Quiz Management',
              children: [
                'Add New Quiz',
                'Manage Quiz',
                'Quiz Overview',
              ],
              onMenuItemSelected: updateSelectedMenu,
              isLargeScreen: widget.isLargeScreen,  // Pass isLargeScreen
            ),
            SidebarButton(
              icon: Icons.priority_high,
              text: 'Roles Manager',
              isSelected: selectedMenu == 'Roles Manager',
              onTap: () => updateSelectedMenu('Roles Manager'),
            ),
            SidebarButton(
              icon: Icons.person,
              text: 'Our Centers',
              isSelected: selectedMenu == 'Our Centers',
              onTap: () => updateSelectedMenu('Our Centers'),
            ),
            SidebarButton(
              icon: Icons.list,
              text: 'Students List',
              isSelected: selectedMenu == 'Students List',
              onTap: () => updateSelectedMenu('Students List'),
            ),
          ],
        ),
      ),
    );
  }

  ExpansionTile _buildExpandableTile({
    required IconData icon,
    required String title,
    required bool isSelected,
    required List<String> children,
    required Function(String) onMenuItemSelected,
    required bool isLargeScreen,
  }) {
    return ExpansionTile(
      leading: Icon(icon, color: isSelected ? Colors.blue : Colors.blueGrey),
      title: Text(
        title,
        style: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w600,
          color: isSelected ? Colors.blue : const Color.fromARGB(136, 0, 0, 0),
        ),
      ),
      initiallyExpanded: isLargeScreen || isSelected,
      onExpansionChanged: (expanded) {
        if (expanded) onMenuItemSelected(title);
      },
      tilePadding: EdgeInsets.symmetric(horizontal: 16),
      children: children.map((item) {
        return SidebarButton(
          icon: Icons.arrow_right,
          text: item,
          isSelected: false,
          onTap: () => onMenuItemSelected(item),
        );
      }).toList(),
    );
  }
}


class SidebarButton extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onTap;
  final bool isSelected;

  SidebarButton({
    required this.icon,
    required this.text,
    required this.onTap,
    this.isSelected = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.symmetric(vertical: 4),
        decoration: BoxDecoration(
          color: isSelected ? Colors.blue : Colors.transparent,
          borderRadius:
              BorderRadius.circular(12), // Applies circular border to all sides
        ),
        child: ListTile(
          leading: Icon(
            icon,
            color: isSelected ? Colors.white : Colors.blueGrey,
          ),
          title: Text(
            text,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w500,
              color: isSelected ? Colors.white : Colors.blueGrey,
            ),
          ),
          contentPadding: EdgeInsets.symmetric(horizontal: 16.0),
          visualDensity: VisualDensity.compact,
        ),
      ),
    );
  }
}
class ContentArea extends StatelessWidget {
  final String selectedContent;
  final TextEditingController searchController;
  final bool isLargeScreen;  // Accepting isLargeScreen

  const ContentArea({required this.selectedContent, required this.searchController, required this.isLargeScreen});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            selectedContent,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.blue[900],
            ),
          ),
          SizedBox(height: 20),
          Expanded(child: _buildContent(selectedContent)),
        ],
      ),
    );
  }

  Widget _buildContent(String selectedContent) {
    switch (selectedContent) {
      case 'Course Content':
        return Dash();
      case 'Priority Task':
        return ModulesList();
      case 'Contact Program Manager':
        return Center(child: Text('Contact details go here.'));
      case 'Raise a Pause Request':
        return Center(child: Text('Pause request form goes here.'));
      case 'Dashboard':
        return Dash();
      default:
        return Center(child: Text('Select a menu item.'));
    }
  }
}